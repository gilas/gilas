$(function() {
	$('.image-grid li:nth-child(3n)').addClass('last');
});